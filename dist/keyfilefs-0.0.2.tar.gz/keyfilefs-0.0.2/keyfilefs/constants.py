#!/usr/bin/env python3

REGEX_FILENAME_RULE = "^[0-9a-zA-Z_\\-\\.]{1,246}$"
KEYFILE_LENGTH = 1024
